iotogglem0_wspl
===============

Author: Hussam Al-Hertani

This is a Template project for the STM32F0 microcontroller. For more information 
Please read "http://hertaville.com/2013/09/03/stm32f0discovery-command-line-ide/".

The template project relies on the STM32F0 Standard peripheral library.
The included makefile can program the chip from the command line using Texane's st-flash utility or OpenOCD.
The included makefile can initiate a debug session from the command line using Texan'e st-util utility or OpenOCD
and the arm-none-eabi-gdbtui utility.
