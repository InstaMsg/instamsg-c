LIBSDIRS="../third_party/stm32f0-environment/STM32F0-Discovery_FW_V1.0.0/Libraries"
CORELIBDIR="${LIBSDIRS}/CMSIS/Include"
DEVDIR="${LIBSDIRS}/CMSIS/ST/STM32F0xx"
STMSPDDIR="${LIBSDIRS}/STM32F0xx_StdPeriph_Driver"
STMSPSRCDDIR="${STMSPDDIR}/src"
STMSPINCDDIR="${STMSPDDIR}/inc"
DISCOVERY="../third_party/stm32f0-environment/STM32F0-Discovery_FW_V1.0.0/Utilities/STM32F0-Discovery"


../third_party/ti-compiler-environment/gcc-arm-none-eabi-4_9-2015q2/bin/arm-none-eabi-gcc -I${DEVDIR}/Include -I${CORELIBDIR} -I${STMSPINCDDIR} -I${DISCOVERY} -Iinc/ -g -gdwarf-2 -mthumb -nostartfiles -mcpu=cortex-m0 -Os -fomit-frame-pointer -Wall -Wstrict-prototypes -fverbose-asm  -DSTM32F0XX -DUSE_STDPERIPH_DRIVER  -T./linker/stm32f0_linker.ld -Wl,-Map=iotogglem0_wspl.map,--cref,--no-warn-mismatch ./startup/startup_stm32f0xx.s src/main.c src/stm32f0xx_it.c ${DEVDIR}/Source/Templates/system_stm32f0xx.c ${STMSPSRCDDIR}/stm32f0xx_gpio.c ${STMSPSRCDDIR}/stm32f0xx_rcc.c ${LIBSDIRS}/STM32F0xx_StdPeriph_Driver/src/stm32f0xx_usart.c -o yeah

../third_party/ti-compiler-environment/gcc-arm-none-eabi-4_9-2015q2/bin/arm-none-eabi-objcopy  -O binary -S yeah flash.bin

sudo ../third_party/stm32f0-environment/stlink/st-flash write flash.bin 0x8000000
