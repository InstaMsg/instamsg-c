LOGIN="root@192.168.1.1"
SSH_COMMAND="ssh ${LOGIN}"

BASE_DIR="device/maestro_e220/setup"

${SSH_COMMAND} "killall instamsg"

HOME_DIRECTORY="/home/sensegrow"


${SSH_COMMAND} "mkdir -p ${HOME_DIRECTORY}"
${SSH_COMMAND} "chmod -R 777 ${HOME_DIRECTORY}"
scp $1  ${LOGIN}:${HOME_DIRECTORY}/instamsg

scp ${BASE_DIR}/monitor.sh  ${LOGIN}:${HOME_DIRECTORY}
${SSH_COMMAND} "chmod 777 ${HOME_DIRECTORY}/monitor.sh"

scp ${BASE_DIR}/cron  ${LOGIN}:${HOME_DIRECTORY}
${SSH_COMMAND} "chmod 777 ${HOME_DIRECTORY}/cron"

${SSH_COMMAND} "cat ${HOME_DIRECTORY}/cron | crontab -"
${SSH_COMMAND} rm ${HOME_DIRECTORY}/cron

${SSH_COMMAND} touch ${HOME_DIRECTORY}/data.txt
${SSH_COMMAND} chmod 777 ${HOME_DIRECTORY}/data.txt
