LOGIN="root@192.168.1.1"
SSH_COMMAND="ssh ${LOGIN}"

BASE_DIR="device/maestro_e220/setup"

${SSH_COMMAND} "killall instamsg"
${SSH_COMMAND} "mv /home/sensegrow/temp /home/sensegrow/instamsg"

HOME_DIRECTORY="/home/sensegrow"

${SSH_COMMAND} "mkdir -p ${HOME_DIRECTORY}"
${SSH_COMMAND} "chmod -R 777 ${HOME_DIRECTORY}"

scp ${BASE_DIR}/monitor.sh  ${LOGIN}:/home/sensegrow
${SSH_COMMAND} "chmod 777 ${HOME_DIRECTORY}/monitor.sh"

scp ${BASE_DIR}/cron  ${LOGIN}:/home/sensegrow
${SSH_COMMAND} "chmod 777 ${HOME_DIRECTORY}/cron"

${SSH_COMMAND} "cat /home/sensegrow/cron | crontab -"
${SSH_COMMAND} rm /home/sensegrow/cron
