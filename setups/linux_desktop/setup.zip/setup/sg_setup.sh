#!/bin/sh

PKG_VERSION="0"

while true
do
    echo
    sleep 1
done
