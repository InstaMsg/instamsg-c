#!/bin/sh

. ./upgrade_params

PKG_VERSION="1"

cp publisher_linux_desktop_3.0.5_3.0.5 "${HOME_DIRECTORY}"


