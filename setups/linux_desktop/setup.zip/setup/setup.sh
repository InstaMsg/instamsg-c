set -x
set -e

HOME_DIRECTORY="/home/sensegrow"

kill -9 `pgrep -x instamsg` || true
cp publisher_lanner-pc_2.71.0_2.71.0 "${HOME_DIRECTORY}/instamsg"
chmod 777 "${HOME_DIRECTORY}/instamsg"
