#!/bin/sh

while true
do
    echo
    sleep 1
done
