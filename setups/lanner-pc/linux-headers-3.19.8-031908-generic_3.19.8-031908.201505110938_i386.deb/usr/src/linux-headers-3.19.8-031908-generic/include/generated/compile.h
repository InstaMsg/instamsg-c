/* This file is auto generated, version 201505110938 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#201505110938 SMP Mon May 11 14:01:21 UTC 2015"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
