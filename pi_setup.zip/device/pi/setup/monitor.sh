PID=`pgrep -x instamsg`

if [ -z "${PID}" ]
then
	echo "Binary not running"

    cd /home/sensegrow
	./instamsg &
else
	echo "Binary running fine"
fi
