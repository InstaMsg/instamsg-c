PID=`pgrep -x instamsg`

if [ -z "${PID}" ]
then
	echo "Binary not running"
    cd /home/sensegrow
    chmod 777 instamsg

    sleep 3
    rm /home/sensegrow/instamsg.log
	./instamsg &
else
	echo "Binary running fine"
fi
