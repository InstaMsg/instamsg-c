sudo kill -9 `pgrep -x pi`
