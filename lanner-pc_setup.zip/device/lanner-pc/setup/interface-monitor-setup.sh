sudo kill `pgrep -x wwan-monitor`

HOME_DIRECTORY="/home/sensegrow"

sudo mkdir -p "${HOME_DIRECTORY}"
sudo chmod -R 777 "${HOME_DIRECTORY}"

sudo cp interface-monitor.sh "${HOME_DIRECTORY}"
sudo chmod 777 "${HOME_DIRECTORY}/interface-monitor.sh"

sudo cp $1 "${HOME_DIRECTORY}/wwan-monitor"
sudo chmod 777 "${HOME_DIRECTORY}/wwan-monitor"
