PID=`pgrep -x instamsg`

if [ -z "${PID}" ]
then
	echo "Binary not running"

    cd /home/sensegrow
    chmod 777 instamsg
    sleep 3
	./instamsg &
else
	echo "Binary running fine"
fi


PID=`pgrep -x wwan-monitor`

if [ -z "${PID}" ]
then
	echo "WWAN-Monitor Binary not running"

    cd /home/sensegrow
    chmod 777 wwan-monitor
    sleep 3
	./wwan-monitor > wwan-monitor.log &
else
	echo "WWAN-Monitor Binary running fine"
fi
