PID=`pgrep -x wwan-monitor`

if [ -z "${PID}" ]
then
	echo "Binary not running"

    cd /home/sensegrow
    sleep 3
	./wwan-monitor &
else
	echo "Binary running fine"
fi
