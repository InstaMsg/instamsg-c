set -e

wget kernel.ubuntu.com/~kernel-ppa/mainline/v3.19.8-vivid/linux-headers-3.19.8-031908_3.19.8-031908.201505110938_all.deb
wget kernel.ubuntu.com/~kernel-ppa/mainline/v3.19.8-vivid/linux-headers-3.19.8-031908-generic_3.19.8-031908.201505110938_i386.deb
wget kernel.ubuntu.com/~kernel-ppa/mainline/v3.19.8-vivid/linux-image-3.19.8-031908-generic_3.19.8-031908.201505110938_i386.deb 
sudo dpkg -i linux-headers-3.19*.deb linux-image-3.19*.deb
sudo update-grub

sudo add-apt-repository -y ppa:aleksander-m/modemmanager-trusty
sudo apt-get update
sudo apt-get install -y modemmanager

sudo echo SUBSYSTEM==\"tty\", ATTRS{idVendor}==\"067b\", ATTRS{idProduct}==\"2303\", ATTRS{serial}==\"0000:00:14.0\", SYMLINK+=\"ttyUSB0\" > /etc/udev/rules.d/99-usb-serial.rules
sudo chmod 777 /etc/udev/rules.d/99-usb-serial.rules

HOME_DIRECTORY="/home/sensegrow"

sudo mkdir -p "${HOME_DIRECTORY}"
sudo chmod -R 777 "${HOME_DIRECTORY}"

sudo cp monitor.sh "${HOME_DIRECTORY}"
sudo chmod 777 "${HOME_DIRECTORY}/monitor.sh"

sudo kill -9 `pgrep -x instamsg` || true
sudo cp $1 "${HOME_DIRECTORY}/instamsg"
sudo chmod 777 "${HOME_DIRECTORY}/instamsg"

sudo touch "${HOME_DIRECTORY}/data.txt"
sudo chmod 777 "${HOME_DIRECTORY}/data.txt"

sudo kill -9 `pgrep -x wwan-monitor` || true
sudo cp wwan-monitor "${HOME_DIRECTORY}"
sudo chmod 777 "${HOME_DIRECTORY}/wwan-monitor"

sudo echo test > ${HOME_DIRECTORY}/prov.txt

sudo crontab < cron

echo
echo
echo "EVERYTHING COMPLETED SUCCESSFULLY ... PLEASE SHUTDOWN THE MACHINE, CONNECT ALL SERIAL-CABLES, AND THEN POWER-UP."
