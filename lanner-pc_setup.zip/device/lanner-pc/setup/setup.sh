sudo add-apt-repository -y ppa:aleksander-m/modemmanager-trusty
sudo apt-get update
sudo apt-get install -y modemmanager

sudo apt-get install -y libgstreamer1.0*

HOME_DIRECTORY="/home/sensegrow"

sudo mkdir -p "${HOME_DIRECTORY}"
sudo chmod -R 777 "${HOME_DIRECTORY}"

sudo cp monitor.sh "${HOME_DIRECTORY}"
sudo chmod 777 "${HOME_DIRECTORY}/monitor.sh"

sudo kill `pgrep -x instamsg`
sudo cp $1 "${HOME_DIRECTORY}/instamsg"
sudo chmod 777 "${HOME_DIRECTORY}/instamsg"

sudo touch "${HOME_DIRECTORY}/data.txt"
sudo chmod 777 "${HOME_DIRECTORY}/data.txt"

sudo kill `pgrep -x wwan-monitor`
sudo cp wwan-monitor "${HOME_DIRECTORY}"
sudo chmod 777 "${HOME_DIRECTORY}/wwan-monitor"

sudo "echo test > ${HOME_DIRECTORY}/prov.txt"

sudo crontab < cron
